'''Uma API é um eito de conectar sistemas, interface de programaçaõ ou aplicativos
API é um conjunto de regras e padrões que permite que diferentes sistemas
de software se comuniquem e troquem dados entre si;
'''

'''Neste exemplo, será utilizada a (((weatherapi.com))) para contruir as condições 
climáticas de determinada localidade'''

'''Consumir API
Vamos precisar de um programa que tenha certa capicidade de pegar dados
mediante a uma URL pré definida'''

import requests #biblioteca para fazer requisições HTTP
from pprint import pprint # biblioteca para imprimir os dados de forma legivel

'''Vamos precisar da APIKEY -> uma credencial '''

API_Key = "4fc3ca8a60f042339dc224505262909"

API_link1 = "http://api.weatherapi.com/v1/astronomy.json"
API_link2 = "http://api.weatherapi.com/v1/current.json"
parametros = {
    "key" : API_Key,
    "q" : "Paris", #cidade objetivo
    "lang" : "pt", #linguagem
    "aqi" : "yes",
    "moon_phase" : "string"
}

# Armazenando a resposta da requisição na variavel resposta
resposta = requests.get(API_link2 and API_link1, params = parametros)


pprint(resposta.status_code)
#status code: 200(sucesso) ou 401(erro)

pprint(resposta) 

if resposta.status_code == 200:
    print("Requisição realizada com sucesso!")
    dados = resposta.json() # Retorna formato JSON, reorganiza os dados de forma mais bonita
    pprint(dados)
    lua = dados["astronomy"]["astro"]["moon_phase"]
    cidade = dados["location"]["name"]
    qualidade_ar = dados["current"]["air_quality"]["us-epa-index"]
    temperatura = dados["current"]["temp_c"] # Armazenando a temp em c°
    descricao = dados["current"]["condition"]["text"] # Armazenando a descrição
    print(f"A temperatura atual em {cidade} é de: {temperatura}°C ")
    print(f"Descrição do clima: {descricao}")
    print(f"Qualidade do Ar: {qualidade_ar}")
    print(f"Fase da lua: {lua}")
else:
    print("Erro na requisição.")

